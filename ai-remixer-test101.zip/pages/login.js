
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const [password, setPassword] = useState('');
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('loggedIn') === 'true') {
      router.push('/');
    }
  }, []);

  const handleLogin = () => {
    if (password === '0000') {
      localStorage.setItem('loggedIn', 'true');
      router.push('/');
    } else {
      alert('Incorrect password!');
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="max-w-sm w-full p-6 bg-white rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-4 text-center">test 101</h1>
        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border w-full px-3 py-2 rounded mb-4"
        />
        <button
          onClick={handleLogin}
          className="bg-black text-white w-full py-2 rounded hover:bg-gray-800"
        >
          Enter
        </button>
      </div>
    </div>
  );
}
