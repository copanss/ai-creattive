
module.exports = {
  reactStrictMode: true,
};
